-- fetch.lua -- downloads and local file resolution.
--
-- Distro-agnostic by construction: we detect curl or wget at runtime rather
-- than assuming one exists, and plain local paths (or file:// URLs) are
-- handled with a straight file copy so offline repositories and local
-- packages need no network at all.

local fetch = {}

local path = require("path")
local log = require("log")
local spinner = require("spinner")
local config = require("config")

local downloader

-- GitHub serves raw file bytes from raw.githubusercontent.com, not from
-- github.com (which returns HTML). Rewrite a github.com repo URL to its raw
-- equivalent. We pin the ref to refs/heads/main instead of the symbolic
-- "HEAD": the raw CDN caches the HEAD ref and can serve stale content long
-- after a push (observed: manifest fetched via /HEAD still had a previous
-- url). refs/heads/main is what the package manifests already use.
function fetch.raw_github(url)
  url = url:gsub("^https?://www%.github%.com/", "https://github.com/")
  local owner, repo, rest = url:match("^https?://github%.com/([^/]+)/([^/]+)(.*)$")
  if owner and repo then
    -- Paths under known GitHub router segments are NOT raw tree paths and
    -- must be left untouched: release assets (releases/download/...) 302 to
    -- the CDN blob store (curl -L follows), and blob/tree/raw/archive/wiki
    -- each have their own resolver. Rewriting them into
    -- raw.githubusercontent.com/OWNER/REPO/refs/heads/main/... yields a
    -- 404 (observed with the libreoffice release asset).
    local kind = rest:match("^/([^/]+)/") or rest:match("^/([^/]+)$") or ""
    if kind == "releases" or kind == "archive" or kind == "blob"
       or kind == "raw" or kind == "tree" or kind == "wiki" then
      return url
    end
    return "https://raw.githubusercontent.com/" .. owner .. "/" .. repo .. "/refs/heads/main" .. rest
  end
  return url
end

local function have(cmd)
  local f = path.popen("command -v " .. cmd .. " 2>/dev/null")
  if not f then return false end
  local out = f:read("*l")
  f:close()
  return out ~= nil and out ~= ""
end

function fetch.downloader()
  if not downloader then
    if have("curl") then
      downloader = "curl"
    elseif have("wget") then
      downloader = "wget"
    else
      downloader = false
    end
  end
  return downloader or nil
end

-- Copy a file, creating parent directories. Used for file:// and local urls.
function fetch.copy(src, dest)
  local f, err = io.open(src, "rb")
  if not f then return nil, err end
  local parts = {}
  while true do
    local chunk = f:read(1048576)
    if not chunk then break end
    parts[#parts + 1] = chunk
  end
  f:close()
  path.mkdir_p(path.dirname(dest))
  local o, oerr = io.open(dest, "wb")
  if not o then return nil, oerr end
  o:write(table.concat(parts))
  o:close()
  return dest
end

-- Progress bar rendering. Draws `[=====----- /]` in place with a rotating
-- spinner character at the end. pct is 0-100, label is printed above the bar.
local BAR_WIDTH = 35
local SPIN_FRAMES = { "/", "-", "\\", "|" }
local spin_idx = 0

local function render_bar(pct, label)
  if label then
    io.write("  " .. label .. "\n")
  end
  local filled = math.floor(BAR_WIDTH * math.min(pct, 100) / 100)
  local empty = BAR_WIDTH - filled
  spin_idx = (spin_idx % #SPIN_FRAMES) + 1
  local spinner_char = SPIN_FRAMES[spin_idx]
  io.write("\r\27[K  [" .. string.rep("=", filled) .. spinner_char .. string.rep(" ", empty) .. "]")
  io.flush()
end

-- Finalize the progress bar line (move to next line, keeping the bar).
local function clear_bar()
  io.write("\n")
  io.flush()
end

-- Download with a progress bar. Runs curl/wget in the background, monitors
-- stderr for progress updates, and renders a bar. Falls back to an
-- indeterminate animated bar for wget (no clean percentage parsing).
function fetch.get_with_progress(url, dest, label)
  local dl = fetch.downloader()
  if not dl then
    return nil, "no downloader found (install curl or wget)"
  end

  local progress_file = dest .. ".progress"
  local script_file = dest .. ".sh"
  local tmp = dest .. ".part"
  path.mkdir_p(path.dirname(dest))

  local script
  if dl == "curl" then
    script = "#!" .. path.shell .. "\n" .. [[URL="$1"
LABEL="$2"
PROG="$3"
TMP="$4"

to_bytes() {
  echo "$1" | awk '
    { v=$1 }
    v ~ /G$/ { gsub(/G/,"",v); printf "%d\n", v*1073741824; next }
    v ~ /M$/ { gsub(/M/,"",v); printf "%d\n", v*1048576; next }
    v ~ /k$/ { gsub(/k/,"",v); printf "%d\n", v*1024; next }
    { gsub(/[^0-9]/,"",v); printf "%d\n", v }
  '
}

BAR_WIDTH=35
FRAMES="/ - \ |"
FI=0

curl -L --fail --show-error -o "$TMP" "$URL" 2>"$PROG" &
CURL_PID=$!

while kill -0 $CURL_PID 2>/dev/null; do
  LINE=$(tr "\r" "\n" < "$PROG" 2>/dev/null | grep -v "^$" | grep -v "^  % Total" | grep -v "^                                 Dload" | tail -1)
  PCT=$(echo "$LINE" | awk '{print $1}')
  TOTAL_RAW=$(echo "$LINE" | awk '{print $2}')
  DL_RAW=$(echo "$LINE" | awk '{print $4}')
  SPD_RAW=$(echo "$LINE" | awk '{print $NF}')
  [ -z "$PCT" ] && PCT=0
  [ -z "$DL_RAW" ] && DL_RAW=0
  [ -z "$TOTAL_RAW" ] && TOTAL_RAW=0
  DL_BYTES=$(to_bytes "$DL_RAW")
  TOTAL_BYTES=$(to_bytes "$TOTAL_RAW")
  SPD_BYTES=$(to_bytes "$SPD_RAW")
  if [ "$TOTAL_BYTES" -gt 0 ] 2>/dev/null; then
    FILLED=$(echo "$DL_BYTES $TOTAL_BYTES $BAR_WIDTH" | awk '{printf "%d", $1 / $2 * $3}')
    PCT=$(echo "$DL_BYTES $TOTAL_BYTES" | awk '{printf "%.1f", $1 * 100 / $2}')
  else
    FILLED=0
    PCT=0
  fi
  EMPTY=$((BAR_WIDTH - FILLED))
  REP=$(printf "%0.s=" $(seq 1 $FILLED 2>/dev/null))
  EMP=$(printf "%0.s " $(seq 1 $EMPTY 2>/dev/null))
  FI=$((FI % 4 + 1))
  SC=$(echo $FRAMES | cut -d" " -f$FI)
  printf "\r\033[K  [%s%s%s] %s/%s  %s%%" "$REP" "$SC" "$EMP" "$DL_RAW" "$TOTAL_RAW" "$PCT"
  # Speed-proportional spinner: faster download = faster rotation.
  if [ "$SPD_BYTES" -gt 1048576 ] 2>/dev/null; then
    sleep 0.03
  elif [ "$SPD_BYTES" -gt 102400 ] 2>/dev/null; then
    sleep 0.06
  else
    sleep 0.1
  fi
done

printf "\n"
wait $CURL_PID
echo $? > "]]  .. dest .. ".rc" .. [["
]]
  else
    -- wget: suppress output, show indeterminate animated bar.
    script = "#!" .. path.shell .. "\n" .. [[URL="$1"
LABEL="$2"
PROG="$3"
TMP="$4"

BAR_WIDTH=35
FRAMES="/ - \ |"
FI=0
FILL=0

wget -q -O "$TMP" "$URL" &
WGET_PID=$!

while kill -0 $WGET_PID 2>/dev/null; do
  FILL=$((FILL + 2))
  if [ $FILL -gt $BAR_WIDTH ]; then FILL=0; fi
  EMPTY=$((BAR_WIDTH - FILL))
  REP=$(printf "%0.s=" $(seq 1 $FILL 2>/dev/null))
  EMP=$(printf "%0.s " $(seq 1 $EMPTY 2>/dev/null))
  FI=$((FI % 4 + 1))
  SC=$(echo $FRAMES | cut -d" " -f$FI)
  printf "\r\033[K  [%s%s%s]" "$REP" "$SC" "$EMP"
  sleep 0.1
done

printf "\n"
wait $WGET_PID
echo $? > "]]  .. dest .. ".rc" .. [["
]]
  end

  local sf = io.open(script_file, "w")
  if not sf then return nil, "cannot create progress script" end
  sf:write(script)
  sf:close()
  os.execute("chmod +x " .. path.quote(script_file))

  -- Run the script: $1=URL $2=LABEL $3=progress_file $4=tmp $5=downloader
  local cmd = path.quote(script_file) .. " "
    .. path.quote(url) .. " "
    .. path.quote(label or "") .. " "
    .. path.quote(progress_file) .. " "
    .. path.quote(tmp) .. " "
    .. path.quote(dl)

  -- Show label above bar if on a terminal.
  if spinner.enabled() and label then
    render_bar(0, label)
  end

  local a, b, c = os.execute(cmd)

  -- Read exit code saved by the script.
  local rc = 1
  local rf = io.open(dest .. ".rc", "r")
  if rf then
    rc = tonumber(rf:read("*a")) or 1
    rf:close()
  end

  -- Clear bar and clean up temp files.
  clear_bar()
  os.remove(progress_file)
  os.remove(script_file)
  os.remove(dest .. ".rc")

  if rc ~= 0 then
    os.remove(tmp)
    return nil, ("download failed: %s"):format(url)
  end
  local r, e = os.rename(tmp, dest)
  if not r then
    os.remove(tmp)
    return nil, e
  end
  return dest
end

-- Resolve `url` into a local file at `dest`. Returns dest or nil, err.
-- When `label` is given and stdout is a terminal, shows a progress bar
-- instead of the plain spinner.
function fetch.get(url, dest, label)
  url = fetch.raw_github(url)
  if url:match("^https?://") then
    path.mkdir_p(path.dirname(dest))
    local dl = fetch.downloader()
    if not dl then
      return nil, "no downloader found (install curl or wget)"
    end
    -- When a label is given and stdout is a terminal, show a progress bar
    -- instead of the plain spinner.
    if label and spinner.enabled() then
      return fetch.get_with_progress(url, dest, label)
    end
    -- Fallback: spinner (or plain log line when piped).
    local spin = spinner.enabled()
    if spin then
      spinner.start(("downloading %s"):format(url))
    else
      log.step(("downloading %s"):format(url))
    end
    local tmp = dest .. ".part"
    local ok
    if dl == "curl" then
      ok = path.run("curl -L --fail --show-error -sS -o " .. path.quote(tmp) .. " " .. path.quote(url))
    else
      local flags = spin and "-q " or ""
      ok = path.run("wget " .. flags .. "-O " .. path.quote(tmp) .. " " .. path.quote(url))
    end
    spinner.stop()
    if not ok then
      os.remove(tmp)
      return nil, ("download failed: %s"):format(url)
    end
    local r, e = os.rename(tmp, dest)
    if not r then
      os.remove(tmp)
      return nil, e
    end
    return dest
  end
  -- file:// prefix, absolute path, or bare relative path
  local src = url:gsub("^file://", "")
  return fetch.copy(src, dest)
end

-- Fetch a small text resource (package.lua, index.lua) and return its
-- contents. The temporary file is removed before returning.
function fetch.read(url, label)
  local name = url:match("[^/]+$") or "zeta"
  local tmp = path.join("/tmp", "zeta-" .. name .. "-" .. tostring(os.time()) .. "-" .. tostring(math.random(10000, 99999)))
  local dest, err = fetch.get(url, tmp, label)
  if not dest then return nil, err end
  local f = io.open(dest, "rb")
  local content
  if f then
    content = f:read("*a")
    f:close()
  end
  os.remove(dest)
  return content, nil
end

-- Download multiple files in parallel. `items` is a list of
--   { url = string, dest = string, label = string (optional) }
-- Optional `opts`: { label = string } overrides the default progress label.
-- Returns a list of results in the same order:
--   { dest = string } on success, or { err = string } on failure.
-- Local/file:// URLs are copied directly (not parallelized).
-- Shows a progress counter: "<label>... [done/total] /"
function fetch.get_parallel(items, opts)
  opts = opts or {}
  local progress_label = opts.label or ("downloading %d packages")
  local dl = fetch.downloader()
  if not dl then
    local results = {}
    for i = 1, #items do
      results[i] = { err = "no downloader found (install curl or wget)" }
    end
    return results
  end

  local remote = {}
  local results = {}
  local tmp_suffix = "-parallel-" .. tostring(os.time()) .. "-" .. tostring(math.random(10000, 99999))

  for i, item in ipairs(items) do
    local url = fetch.raw_github(item.url)
    local dest = item.dest
    path.mkdir_p(path.dirname(dest))

    if not url:match("^https?://") then
      local src = url:gsub("^file://", "")
      local ok, err = fetch.copy(src, dest)
      results[i] = ok and { dest = dest } or { err = err }
    else
      local tmp = dest .. tmp_suffix
      remote[#remote + 1] = { url = url, dest = dest, tmp = tmp, idx = i, label = item.label }
      results[i] = { pending = true }
    end
  end

  if #remote == 0 then
    return results
  end

  local progress_file = "/tmp/zeta-progress-" .. tmp_suffix
  local rc_file = "/tmp/zeta-rc-" .. tmp_suffix

  local script_lines = {
    "#!" .. path.shell,
    "fail=0",
    "progress=" .. path.quote(progress_file),
    "> \"$progress\"",
  }

  -- Verbose: show all download URLs before starting.
  if config.get().verbose then
    for _, r in ipairs(remote) do
      log.detail(("  fetch %s -> %s"):format(r.url, r.tmp))
    end
  end

  for _, r in ipairs(remote) do
    local dl_cmd
    if dl == "curl" then
      dl_cmd = "curl -L --fail --show-error -sS -o " .. path.quote(r.tmp) .. " " .. path.quote(r.url)
    else
      dl_cmd = "wget -q -O " .. path.quote(r.tmp) .. " " .. path.quote(r.url)
    end
    script_lines[#script_lines + 1] = dl_cmd .. " && echo " .. r.idx .. " >> \"$progress\" || true &"
    script_lines[#script_lines + 1] = "PID_" .. r.idx .. "=$!"
  end
  for _, r in ipairs(remote) do
    script_lines[#script_lines + 1] = "wait $PID_" .. r.idx .. " || fail=1"
  end
  script_lines[#script_lines + 1] = "echo $fail > " .. path.quote(rc_file)
  script_lines[#script_lines + 1] = "exit $fail"

  local script_path = path.join("/tmp", "zeta-parallel" .. tmp_suffix .. ".sh")
  local sf = io.open(script_path, "w")
  if not sf then
    for _, r in ipairs(remote) do
      results[r.idx] = { err = "cannot create parallel download script" }
    end
    return results
  end
  sf:write(table.concat(script_lines, "\n") .. "\n")
  sf:close()
  os.execute("chmod +x " .. path.quote(script_path))

  -- Launch script in background
  local pid_file = "/tmp/zeta-pid-" .. tmp_suffix
  os.execute(path.quote(script_path) .. " & echo $! > " .. path.quote(pid_file))

  -- Read the PID
  local pid = nil
  local pf = io.open(pid_file, "r")
  if pf then
    pid = pf:read("*l")
    pf:close()
  end
  os.remove(pid_file)

  -- Progress display
  local completed = 0
  local total = #remote
  local use_spinner = spinner.enabled()
  local seen = {}
  local last_name = ""

  -- Print the header line once.
  if use_spinner then
    io.write("  " .. progress_label:format(total) .. "...\n")
    io.flush()
  end

  local start_time = os.time()
  local slow_warned = false

  while pid and path.run("kill -0 " .. pid .. " 2>/dev/null") do
    -- Count completed downloads and find the newest completion.
    local f = io.open(progress_file, "r")
    if f then
      local count = 0
      for line in f:lines() do
        count = count + 1
        local idx = tonumber(line)
        if idx and not seen[idx] then
          seen[idx] = true
          last_name = remote[idx].label or ""
        end
      end
      f:close()
      if count > completed then
        completed = count
      end
    end

    if use_spinner then
      local pct = math.floor(100 * completed / total)
      local filled = math.floor(BAR_WIDTH * pct / 100)
      local empty = BAR_WIDTH - filled
      spin_idx = (spin_idx % #SPIN_FRAMES) + 1
      local spinner_char = SPIN_FRAMES[spin_idx]
      io.write(("\r\27[K  [" .. string.rep("=", filled) .. "%s" .. string.rep(" ", empty) .. "] %s  %d/%d"):format(spinner_char, last_name, completed, total))
      io.flush()
    end
    os.execute("sleep 0.1")
    if not slow_warned and os.time() - start_time > 30 then
      slow_warned = true
      io.write("\n  download is taking longer than expected, hang in there.\n")
      io.flush()
    end
  end

  -- Final count.
  local f = io.open(progress_file, "r")
  if f then
    local count = 0
    for line in f:lines() do
      count = count + 1
      local idx = tonumber(line)
      if idx and not seen[idx] then
        seen[idx] = true
        last_name = remote[idx].label or ""
      end
    end
    f:close()
    completed = count
  end

  if use_spinner then
    local filled = BAR_WIDTH
    io.write(("\r\27[K  [" .. string.rep("=", filled) .. "] %s  %d/%d\n"):format(last_name, completed, total))
    io.flush()
  else
    log.step(progress_label:format(total) .. "... [" .. completed .. "/" .. total .. "]")
  end

  -- Read exit code
  local ok = true
  local rf = io.open(rc_file, "r")
  if rf then
    local rc = tonumber(rf:read("*a")) or 1
    rf:close()
    ok = (rc == 0)
  end

  -- Cleanup
  os.remove(script_path)
  os.remove(progress_file)
  os.remove(rc_file)

  for _, r in ipairs(remote) do
    if not ok then
      os.remove(r.tmp)
      results[r.idx] = { err = ("download failed: %s"):format(r.url) }
    else
      local renamed, ren_err = os.rename(r.tmp, r.dest)
      if renamed then
        results[r.idx] = { dest = r.dest }
      else
        os.remove(r.tmp)
        results[r.idx] = { err = ren_err }
      end
    end
  end

  return results
end

return fetch
